# `python-2.7.18-embed-amd64`

Embeddable Python 2.7.18 amd64 package for Windows built from `python-2.7.18.amd64.msi`

**This version of Python is deprecated, please only use it if you have to!! Port your stuff to Python 3!**